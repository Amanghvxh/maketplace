import { h } from 'preact'

import { Helmet } from 'react-helmet'

import styles from './style.css'

const Home = (props) => {
  return (
    <div class={styles['container']}>
      <Helmet>
        <title>Made Up Spotless Emu</title>
        <meta property="og:title" content="Made Up Spotless Emu" />
      </Helmet>
      <div class={styles['frame1']}>
        <div class={styles['frame2']}>
          <img
            src="/assets/playground_assets/a5343180082741d290fd3d2ea80d70e0125-7wa-1100w.png"
            alt="a5343180082741d290fd3d2ea80d70e0125"
            class={styles['a5343180082741d290fd3d2ea80d70e01']}
          />
        </div>
        <div class={styles['frame8']}>
          <span class={styles['text']}>
            <span>LOREM IPSUM LOREMUPSUM</span>
          </span>
          <span class={styles['text02']}>
            <span>
              <span>LOREM IPSUM</span>
              <br></br>
              <span>LOREMUPSUM</span>
            </span>
          </span>
          <span class={styles['text07']}>
            <span>
              LOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM
              LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPS
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </span>
          <img
            src="/assets/playground_assets/rectangle2283-jwq-200h.png"
            alt="Rectangle2283"
            class={styles['rectangle2']}
          />
          <img
            src="/assets/playground_assets/rectangle3285-vj.svg"
            alt="Rectangle3285"
            class={styles['rectangle3']}
          />
          <img
            src="/assets/playground_assets/rectangle4286-kk1l-200h.png"
            alt="Rectangle4286"
            class={styles['rectangle4']}
          />
          <span class={styles['text09']}>
            <span>JOIN AS SELLER</span>
          </span>
          <span class={styles['text11']}>
            <span>JOIN AS BUYER</span>
          </span>
        </div>
        <div class={styles['frame7']}>
          <span class={styles['text13']}>
            <span>
              <span>LOGO</span>
              <br></br>
              <span>LOGO</span>
            </span>
          </span>
          <span class={styles['text18']}>
            <span>HOME</span>
          </span>
          <span class={styles['text20']}>
            <span>CONTACTUS</span>
          </span>
          <span class={styles['text22']}>
            <span>LOGIN</span>
          </span>
          <span class={styles['text24']}>
            <span>SIGNUP</span>
          </span>
        </div>
        <div class={styles['frame9']}>
          <div class={styles['frame10']}>
            <div class={styles['frame6']}>
              <div class={styles['group1']}>
                <div class={styles['frame4']}>
                  <img
                    src="/assets/playground_assets/tomatoes11239-896-200h.png"
                    alt="tomatoes11239"
                    class={styles['tomatoes11']}
                  />
                </div>
                <img
                  src="/assets/playground_assets/line1244-ojde.svg"
                  alt="Line1244"
                  class={styles['line1']}
                />
                <img
                  src="/assets/playground_assets/rectangle1267-un7-200h.png"
                  alt="Rectangle1267"
                  class={styles['rectangle1']}
                />
                <img
                  src="/assets/playground_assets/ellipse1268-52h-200h.png"
                  alt="Ellipse1268"
                  class={styles['ellipse1']}
                />
                <span class={styles['text26']}>
                  <span>Lorem ipsum</span>
                </span>
                <span class={styles['text28']}>
                  <span>lorem ipsum</span>
                </span>
                <span class={styles['text30']}>
                  <span>BLUEBERRIES</span>
                </span>
                <span class={styles['text32']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div class={styles['frame5']}>
              <div class={styles['group11']}>
                <div class={styles['frame41']}>
                  <img
                    src="/assets/playground_assets/tomatoes11229-h4nf-200h.png"
                    alt="tomatoes11229"
                    class={styles['tomatoes111']}
                  />
                </div>
                <img
                  src="/assets/playground_assets/line1234-bcec.svg"
                  alt="Line1234"
                  class={styles['line11']}
                />
                <img
                  src="/assets/playground_assets/rectangle1257-w85m-200h.png"
                  alt="Rectangle1257"
                  class={styles['rectangle11']}
                />
                <img
                  src="/assets/playground_assets/ellipse1258-cyed-200h.png"
                  alt="Ellipse1258"
                  class={styles['ellipse11']}
                />
                <span class={styles['text37']}>
                  <span>Lorem ipsum</span>
                </span>
                <span class={styles['text39']}>
                  <span>lorem ipsum</span>
                </span>
                <span class={styles['text41']}>
                  <span>GRAPES</span>
                </span>
                <span class={styles['text43']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div class={styles['frame42']}>
              <div class={styles['group12']}>
                <div class={styles['frame43']}>
                  <img
                    src="/assets/playground_assets/tomatoes11219-spvk-200h.png"
                    alt="tomatoes11219"
                    class={styles['tomatoes112']}
                  />
                </div>
                <img
                  src="/assets/playground_assets/line1224-gjkn.svg"
                  alt="Line1224"
                  class={styles['line12']}
                />
                <img
                  src="/assets/playground_assets/rectangle1262-j15p-200h.png"
                  alt="Rectangle1262"
                  class={styles['rectangle12']}
                />
                <img
                  src="/assets/playground_assets/ellipse1263-aicm-200h.png"
                  alt="Ellipse1263"
                  class={styles['ellipse12']}
                />
                <span class={styles['text48']}>
                  <span>Lorem ipsum</span>
                </span>
                <span class={styles['text50']}>
                  <span>lorem ipsum</span>
                </span>
                <span class={styles['text52']}>
                  <span>PEACHES</span>
                </span>
                <span class={styles['text54']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div class={styles['frame3']}>
              <div class={styles['group13']}>
                <div class={styles['frame44']}>
                  <img
                    src="/assets/playground_assets/tomatoes11215-dlvn-200h.png"
                    alt="tomatoes11215"
                    class={styles['tomatoes113']}
                  />
                </div>
                <img
                  src="/assets/playground_assets/rectangle128-bks9-200h.png"
                  alt="Rectangle128"
                  class={styles['rectangle13']}
                />
                <img
                  src="/assets/playground_assets/ellipse129-9ptr-200h.png"
                  alt="Ellipse129"
                  class={styles['ellipse13']}
                />
                <span class={styles['text59']}>
                  <span>Lorem ipsum</span>
                </span>
                <span class={styles['text61']}>
                  <span>lorem ipsum</span>
                </span>
                <span class={styles['text63']}>
                  <span>TOMATOS</span>
                </span>
                <img
                  src="/assets/playground_assets/line1212-b6qa.svg"
                  alt="Line1212"
                  class={styles['line13']}
                />
                <span class={styles['text65']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
