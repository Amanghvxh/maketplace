import "~/./assets/style.css";
export default function (Vue, {
  router: router,
  head: head,
  isClient: isClient
}) {}
