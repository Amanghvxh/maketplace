<template>
  <div class="home-container">
    <div class="home-frame1">
      <div class="home-frame2">
        <img
          src="/playground_assets/a5343180082741d290fd3d2ea80d70e0125-7wa-1100w.png"
          alt="a5343180082741d290fd3d2ea80d70e0125"
          class="home-a5343180082741d290fd3d2ea80d70e01"
        />
      </div>
      <div class="home-frame8">
        <span class="home-text"><span>LOREM IPSUM LOREMUPSUM</span></span>
        <span class="home-text02">
          <span>
            <span>LOREM IPSUM</span>
            <br />
            <span>LOREMUPSUM</span>
          </span>
        </span>
        <span class="home-text07">
          <span>
            LOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM
            LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPS
            <span v-html="raw3siy"></span>
          </span>
        </span>
        <img
          src="/playground_assets/rectangle2283-jwq-200h.png"
          alt="Rectangle2283"
          class="home-rectangle2"
        />
        <img
          src="/playground_assets/rectangle3285-vj.svg"
          alt="Rectangle3285"
          class="home-rectangle3"
        />
        <img
          src="/playground_assets/rectangle4286-kk1l-200h.png"
          alt="Rectangle4286"
          class="home-rectangle4"
        />
        <span class="home-text09"><span>JOIN AS SELLER</span></span>
        <span class="home-text11"><span>JOIN AS BUYER</span></span>
      </div>
      <div class="home-frame7">
        <span class="home-text13">
          <span>
            <span>LOGO</span>
            <br />
            <span>LOGO</span>
          </span>
        </span>
        <span class="home-text18"><span>HOME</span></span>
        <span class="home-text20"><span>CONTACTUS</span></span>
        <span class="home-text22"><span>LOGIN</span></span>
        <span class="home-text24"><span>SIGNUP</span></span>
      </div>
      <div class="home-frame9">
        <div class="home-frame10">
          <div class="home-frame6">
            <div class="home-group1">
              <div class="home-frame4">
                <img
                  src="/playground_assets/tomatoes11239-896-200h.png"
                  alt="tomatoes11239"
                  class="home-tomatoes11"
                />
              </div>
              <img
                src="/playground_assets/line1244-ojde.svg"
                alt="Line1244"
                class="home-line1"
              />
              <img
                src="/playground_assets/rectangle1267-un7-200h.png"
                alt="Rectangle1267"
                class="home-rectangle1"
              />
              <img
                src="/playground_assets/ellipse1268-52h-200h.png"
                alt="Ellipse1268"
                class="home-ellipse1"
              />
              <span class="home-text26"><span>Lorem ipsum</span></span>
              <span class="home-text28"><span>lorem ipsum</span></span>
              <span class="home-text30"><span>BLUEBERRIES</span></span>
              <span class="home-text32">
                <span>
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="rawjt45"></span>
                  </span>
                  <br />
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="raw52f9"></span>
                  </span>
                </span>
              </span>
            </div>
          </div>
          <div class="home-frame5">
            <div class="home-group11">
              <div class="home-frame41">
                <img
                  src="/playground_assets/tomatoes11229-h4nf-200h.png"
                  alt="tomatoes11229"
                  class="home-tomatoes111"
                />
              </div>
              <img
                src="/playground_assets/line1234-bcec.svg"
                alt="Line1234"
                class="home-line11"
              />
              <img
                src="/playground_assets/rectangle1257-w85m-200h.png"
                alt="Rectangle1257"
                class="home-rectangle11"
              />
              <img
                src="/playground_assets/ellipse1258-cyed-200h.png"
                alt="Ellipse1258"
                class="home-ellipse11"
              />
              <span class="home-text37"><span>Lorem ipsum</span></span>
              <span class="home-text39"><span>lorem ipsum</span></span>
              <span class="home-text41"><span>GRAPES</span></span>
              <span class="home-text43">
                <span>
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="rawso2c"></span>
                  </span>
                  <br />
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="rawru74"></span>
                  </span>
                </span>
              </span>
            </div>
          </div>
          <div class="home-frame42">
            <div class="home-group12">
              <div class="home-frame43">
                <img
                  src="/playground_assets/tomatoes11219-spvk-200h.png"
                  alt="tomatoes11219"
                  class="home-tomatoes112"
                />
              </div>
              <img
                src="/playground_assets/line1224-gjkn.svg"
                alt="Line1224"
                class="home-line12"
              />
              <img
                src="/playground_assets/rectangle1262-j15p-200h.png"
                alt="Rectangle1262"
                class="home-rectangle12"
              />
              <img
                src="/playground_assets/ellipse1263-aicm-200h.png"
                alt="Ellipse1263"
                class="home-ellipse12"
              />
              <span class="home-text48"><span>Lorem ipsum</span></span>
              <span class="home-text50"><span>lorem ipsum</span></span>
              <span class="home-text52"><span>PEACHES</span></span>
              <span class="home-text54">
                <span>
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="raw6ns5"></span>
                  </span>
                  <br />
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="raw61v5"></span>
                  </span>
                </span>
              </span>
            </div>
          </div>
          <div class="home-frame3">
            <div class="home-group13">
              <div class="home-frame44">
                <img
                  src="/playground_assets/tomatoes11215-dlvn-200h.png"
                  alt="tomatoes11215"
                  class="home-tomatoes113"
                />
              </div>
              <img
                src="/playground_assets/rectangle128-bks9-200h.png"
                alt="Rectangle128"
                class="home-rectangle13"
              />
              <img
                src="/playground_assets/ellipse129-9ptr-200h.png"
                alt="Ellipse129"
                class="home-ellipse13"
              />
              <span class="home-text59"><span>Lorem ipsum</span></span>
              <span class="home-text61"><span>lorem ipsum</span></span>
              <span class="home-text63"><span>TOMATOS</span></span>
              <img
                src="/playground_assets/line1212-b6qa.svg"
                alt="Line1212"
                class="home-line13"
              />
              <span class="home-text65">
                <span>
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="rawipor"></span>
                  </span>
                  <br />
                  <span>
                    Lorem ipsum Lorem ipsum
                    <span v-html="raw16g7"></span>
                  </span>
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',

  data() {
    return {
      raw3siy: ' ',
      rawjt45: ' ',
      raw52f9: ' ',
      rawso2c: ' ',
      rawru74: ' ',
      raw6ns5: ' ',
      raw61v5: ' ',
      rawipor: ' ',
      raw16g7: ' ',
    }
  },

  metaInfo: {
    title: 'Made Up Spotless Emu',
    meta: [
      {
        property: 'og:title',
        content: 'Made Up Spotless Emu',
      },
    ],
  },
}
</script>

<style scoped>
.home-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
}
.home-frame1 {
  width: 1011px;
  height: 1024px;
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-color: rgba(38, 77, 114, 1);
}
.home-frame2 {
  top: 50px;
  left: 35px;
  width: 941px;
  height: 727px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-color: rgba(255, 255, 255, 1);
}
.home-a5343180082741d290fd3d2ea80d70e01 {
  top: -37px;
  left: -42px;
  width: 1024px;
  height: 773px;
  position: absolute;
  border-color: transparent;
}
.home-frame8 {
  top: 199px;
  left: 54px;
  width: 391px;
  height: 398px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
}
.home-text {
  top: 19px;
  left: 41px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 12px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text02 {
  top: 45px;
  left: 41px;
  color: rgba(255, 255, 255, 1);
  width: 298px;
  height: auto;
  position: absolute;
  font-size: 42px;
  align-self: auto;
  font-style: Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text07 {
  top: 209px;
  left: 40px;
  color: rgba(245, 245, 245, 1);
  width: 261px;
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Light;
  text-align: left;
  font-family: Inter;
  font-weight: 300;
  line-height: 20px;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-rectangle2 {
  top: 293px;
  left: 35px;
  width: 114px;
  height: 24px;
  position: absolute;
  box-sizing: content-box;
  border-color: transparent;
}
.home-rectangle3 {
  top: 293px;
  left: 35px;
  width: 120px;
  height: 24px;
  position: absolute;
  box-shadow: 0px 0px 1px 0px rgba(0, 0, 0, 0.5400000214576721) ;
  box-sizing: content-box;
}
.home-rectangle4 {
  top: 293px;
  left: 195px;
  width: 120px;
  height: 24px;
  position: absolute;
  box-sizing: content-box;
  border-color: rgba(255, 255, 255, 1);
  border-style: solid;
  border-width: 1px;
  border-radius: 5px;
}
.home-text09 {
  top: 295px;
  left: 56px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: 20px;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text11 {
  top: 295px;
  left: 216px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: 20px;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-frame7 {
  top: 53px;
  left: 35px;
  width: 934px;
  height: 81px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-color: rgba(0, 0, 0, 0.09000000357627869);
}
.home-text13 {
  top: 19px;
  left: 42px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 17px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text18 {
  top: 33px;
  left: 214px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 14px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text20 {
  top: 33px;
  left: 279px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 14px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text22 {
  top: 33px;
  left: 382px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 14px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-text24 {
  top: 33px;
  left: 440px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 14px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  margin-right: 0;
  margin-bottom: 0;
  text-decoration: none;
}
.home-frame9 {
  top: 658px;
  left: 0px;
  width: 1010px;
  height: 370px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-size: cover;
  background-image: url("/playground_assets/77ffc8ad-32f4-428e-82f5-69cced82ca57-f5us-400h.undefined");
}
.home-frame10 {
  top: 33px;
  left: 71px;
  width: 868px;
  height: 300px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
}
.home-frame6 {
  top: 2px;
  left: 649px;
  width: 219px;
  height: 316px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-image: linear-gradient(180deg, rgba(17, 42, 65, 1) 0%, rgba(18, 77, 101, 1) 100%);
}
.home-group1 {
  top: 31px;
  left: 26px;
  width: 166px;
  height: 254px;
  display: flex;
  padding: 0;
  position: absolute;
  align-self: auto;
  box-sizing: border-box;
  align-items: flex-start;
  flex-shrink: 1;
  border-color: transparent;
  border-style: none;
  border-width: 0;
  margin-right: 0;
  border-radius: 0px 0px 0px 0px;
  margin-bottom: 0;
  flex-direction: row;
  justify-content: flex-start;
  background-color: transparent;
}
.home-frame4 {
  top: 144px;
  left: 0px;
  width: 166px;
  height: 110px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: rgba(0, 0, 0, 1);
  border-style: solid;
  border-width: 3px;
  border-radius: 20px;
  background-color: rgba(255, 255, 255, 1);
}
.home-tomatoes11 {
  top: 0px;
  left: 0px;
  width: 166px;
  height: 110px;
  position: absolute;
  border-color: transparent;
}
.home-line1 {
  top: 41px;
  left: 10px;
  width: 148px;
  height: 0px;
  position: absolute;
}
.home-rectangle1 {
  top: 94px;
  left: 11px;
  width: 51px;
  height: 21px;
  position: absolute;
  border-color: transparent;
}
.home-ellipse1 {
  top: 98px;
  left: 71px;
  width: 7px;
  height: 6px;
  position: absolute;
  border-color: transparent;
}
.home-text26 {
  top: 92px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 11px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text28 {
  top: 115px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text30 {
  top: 59px;
  left: 10px;
  color: rgba(245, 245, 245, 1);
  height: auto;
  position: absolute;
  font-size: 17px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text32 {
  left: 10px;
  color: rgba(72, 115, 156, 1);
  width: 156px;
  height: auto;
  position: absolute;
  font-size: 12px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-frame5 {
  top: 2px;
  left: 437px;
  width: 219px;
  height: 316px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-image: linear-gradient(180deg, rgba(17, 42, 65, 1) 0%, rgba(18, 77, 101, 1) 100%);
}
.home-group11 {
  top: 31px;
  left: 26px;
  width: 166px;
  height: 254px;
  display: flex;
  padding: 0;
  position: absolute;
  align-self: auto;
  box-sizing: border-box;
  align-items: flex-start;
  flex-shrink: 1;
  border-color: transparent;
  border-style: none;
  border-width: 0;
  margin-right: 0;
  border-radius: 0px 0px 0px 0px;
  margin-bottom: 0;
  flex-direction: row;
  justify-content: flex-start;
  background-color: transparent;
}
.home-frame41 {
  top: 144px;
  left: 0px;
  width: 166px;
  height: 110px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: rgba(0, 0, 0, 1);
  border-style: solid;
  border-width: 3px;
  border-radius: 20px;
  background-color: rgba(255, 255, 255, 1);
}
.home-tomatoes111 {
  top: 0px;
  left: 0px;
  width: 166px;
  height: 110px;
  position: absolute;
  border-color: transparent;
}
.home-line11 {
  top: 41px;
  left: 10px;
  width: 148px;
  height: 0px;
  position: absolute;
}
.home-rectangle11 {
  top: 94px;
  left: 10px;
  width: 51px;
  height: 21px;
  position: absolute;
  border-color: transparent;
}
.home-ellipse11 {
  top: 98px;
  left: 71px;
  width: 7px;
  height: 6px;
  position: absolute;
  border-color: transparent;
}
.home-text37 {
  top: 92px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 11px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text39 {
  top: 115px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text41 {
  top: 59px;
  left: 10px;
  color: rgba(245, 245, 245, 1);
  height: auto;
  position: absolute;
  font-size: 17px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text43 {
  left: 10px;
  color: rgba(72, 115, 156, 1);
  width: 156px;
  height: auto;
  position: absolute;
  font-size: 12px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-frame42 {
  top: 2px;
  left: 218px;
  width: 219px;
  height: 316px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-image: linear-gradient(180deg, rgba(17, 42, 65, 1) 0%, rgba(18, 77, 101, 1) 100%);
}
.home-group12 {
  top: 31px;
  left: 26px;
  width: 166px;
  height: 254px;
  display: flex;
  padding: 0;
  position: absolute;
  align-self: auto;
  box-sizing: border-box;
  align-items: flex-start;
  flex-shrink: 1;
  border-color: transparent;
  border-style: none;
  border-width: 0;
  margin-right: 0;
  border-radius: 0px 0px 0px 0px;
  margin-bottom: 0;
  flex-direction: row;
  justify-content: flex-start;
  background-color: transparent;
}
.home-frame43 {
  top: 144px;
  left: 0px;
  width: 166px;
  height: 110px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: rgba(0, 0, 0, 1);
  border-style: solid;
  border-width: 3px;
  border-radius: 20px;
  background-color: rgba(255, 255, 255, 1);
}
.home-tomatoes112 {
  top: 0px;
  left: 0px;
  width: 166px;
  height: 110px;
  position: absolute;
  border-color: transparent;
}
.home-line12 {
  top: 41px;
  left: 10px;
  width: 148px;
  height: 0px;
  position: absolute;
}
.home-rectangle12 {
  top: 94px;
  left: 10px;
  width: 51px;
  height: 21px;
  position: absolute;
  border-color: transparent;
}
.home-ellipse12 {
  top: 98px;
  left: 71px;
  width: 7px;
  height: 6px;
  position: absolute;
  border-color: transparent;
}
.home-text48 {
  top: 92px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 11px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text50 {
  top: 115px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text52 {
  top: 59px;
  left: 10px;
  color: rgba(245, 245, 245, 1);
  height: auto;
  position: absolute;
  font-size: 17px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text54 {
  left: 10px;
  color: rgba(72, 115, 156, 1);
  width: 156px;
  height: auto;
  position: absolute;
  font-size: 12px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-frame3 {
  top: 2px;
  left: -1px;
  width: 219px;
  height: 316px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: transparent;
  background-image: linear-gradient(180deg, rgba(17, 42, 65, 1) 0%, rgba(18, 77, 101, 1) 100%);
}
.home-group13 {
  top: 31px;
  left: 26px;
  width: 166px;
  height: 254px;
  display: flex;
  padding: 0;
  position: absolute;
  align-self: auto;
  box-sizing: border-box;
  align-items: flex-start;
  flex-shrink: 1;
  border-color: transparent;
  border-style: none;
  border-width: 0;
  margin-right: 0;
  border-radius: 0px 0px 0px 0px;
  margin-bottom: 0;
  flex-direction: row;
  justify-content: flex-start;
  background-color: transparent;
}
.home-frame44 {
  top: 144px;
  left: 0px;
  width: 166px;
  height: 110px;
  display: flex;
  overflow: hidden;
  position: absolute;
  align-items: flex-start;
  flex-shrink: 0;
  border-color: rgba(0, 0, 0, 1);
  border-style: solid;
  border-width: 3px;
  border-radius: 20px;
  background-color: rgba(255, 255, 255, 1);
}
.home-tomatoes113 {
  top: 0px;
  left: 0px;
  width: 166px;
  height: 110px;
  position: absolute;
  border-color: transparent;
}
.home-rectangle13 {
  top: 94px;
  left: 10px;
  width: 51px;
  height: 21px;
  position: absolute;
  border-color: transparent;
}
.home-ellipse13 {
  top: 98px;
  left: 71px;
  width: 7px;
  height: 6px;
  position: absolute;
  border-color: transparent;
}
.home-text59 {
  top: 92px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 11px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text61 {
  top: 115px;
  left: 98px;
  color: rgba(255, 255, 255, 1);
  height: auto;
  position: absolute;
  font-size: 10px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-text63 {
  top: 59px;
  left: 10px;
  color: rgba(245, 245, 245, 1);
  height: auto;
  position: absolute;
  font-size: 17px;
  align-self: auto;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.home-line13 {
  top: 41px;
  left: 10px;
  width: 148px;
  height: 0px;
  position: absolute;
}
.home-text65 {
  left: 10px;
  color: rgba(72, 115, 156, 1);
  width: 156px;
  height: auto;
  position: absolute;
  font-size: 12px;
  align-self: auto;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
</style>
