export default {
  css: [`~/style.css`],
  plugins: [`~/plugins/lottie-vue-player.client.js`]
};
