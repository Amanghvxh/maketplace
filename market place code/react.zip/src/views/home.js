import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Made Up Spotless Emu</title>
        <meta property="og:title" content="Made Up Spotless Emu" />
      </Helmet>
      <div className="home-frame1">
        <div className="home-frame2">
          <img
            src="/playground_assets/a5343180082741d290fd3d2ea80d70e0125-7wa-1100w.png"
            alt="a5343180082741d290fd3d2ea80d70e0125"
            className="home-a5343180082741d290fd3d2ea80d70e01"
          />
        </div>
        <div className="home-frame8">
          <span className="home-text">
            <span>LOREM IPSUM LOREMUPSUM</span>
          </span>
          <span className="home-text02">
            <span>
              <span>LOREM IPSUM</span>
              <br></br>
              <span>LOREMUPSUM</span>
            </span>
          </span>
          <span className="home-text07">
            <span>
              LOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM
              LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPS
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </span>
          <img
            src="/playground_assets/rectangle2283-jwq-200h.png"
            alt="Rectangle2283"
            className="home-rectangle2"
          />
          <img
            src="/playground_assets/rectangle3285-vj.svg"
            alt="Rectangle3285"
            className="home-rectangle3"
          />
          <img
            src="/playground_assets/rectangle4286-kk1l-200h.png"
            alt="Rectangle4286"
            className="home-rectangle4"
          />
          <span className="home-text09">
            <span>JOIN AS SELLER</span>
          </span>
          <span className="home-text11">
            <span>JOIN AS BUYER</span>
          </span>
        </div>
        <div className="home-frame7">
          <span className="home-text13">
            <span>
              <span>LOGO</span>
              <br></br>
              <span>LOGO</span>
            </span>
          </span>
          <span className="home-text18">
            <span>HOME</span>
          </span>
          <span className="home-text20">
            <span>CONTACTUS</span>
          </span>
          <span className="home-text22">
            <span>LOGIN</span>
          </span>
          <span className="home-text24">
            <span>SIGNUP</span>
          </span>
        </div>
        <div className="home-frame9">
          <div className="home-frame10">
            <div className="home-frame6">
              <div className="home-group1">
                <div className="home-frame4">
                  <img
                    src="/playground_assets/tomatoes11239-896-200h.png"
                    alt="tomatoes11239"
                    className="home-tomatoes11"
                  />
                </div>
                <img
                  src="/playground_assets/line1244-ojde.svg"
                  alt="Line1244"
                  className="home-line1"
                />
                <img
                  src="/playground_assets/rectangle1267-un7-200h.png"
                  alt="Rectangle1267"
                  className="home-rectangle1"
                />
                <img
                  src="/playground_assets/ellipse1268-52h-200h.png"
                  alt="Ellipse1268"
                  className="home-ellipse1"
                />
                <span className="home-text26">
                  <span>Lorem ipsum</span>
                </span>
                <span className="home-text28">
                  <span>lorem ipsum</span>
                </span>
                <span className="home-text30">
                  <span>BLUEBERRIES</span>
                </span>
                <span className="home-text32">
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div className="home-frame5">
              <div className="home-group11">
                <div className="home-frame41">
                  <img
                    src="/playground_assets/tomatoes11229-h4nf-200h.png"
                    alt="tomatoes11229"
                    className="home-tomatoes111"
                  />
                </div>
                <img
                  src="/playground_assets/line1234-bcec.svg"
                  alt="Line1234"
                  className="home-line11"
                />
                <img
                  src="/playground_assets/rectangle1257-w85m-200h.png"
                  alt="Rectangle1257"
                  className="home-rectangle11"
                />
                <img
                  src="/playground_assets/ellipse1258-cyed-200h.png"
                  alt="Ellipse1258"
                  className="home-ellipse11"
                />
                <span className="home-text37">
                  <span>Lorem ipsum</span>
                </span>
                <span className="home-text39">
                  <span>lorem ipsum</span>
                </span>
                <span className="home-text41">
                  <span>GRAPES</span>
                </span>
                <span className="home-text43">
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div className="home-frame42">
              <div className="home-group12">
                <div className="home-frame43">
                  <img
                    src="/playground_assets/tomatoes11219-spvk-200h.png"
                    alt="tomatoes11219"
                    className="home-tomatoes112"
                  />
                </div>
                <img
                  src="/playground_assets/line1224-gjkn.svg"
                  alt="Line1224"
                  className="home-line12"
                />
                <img
                  src="/playground_assets/rectangle1262-j15p-200h.png"
                  alt="Rectangle1262"
                  className="home-rectangle12"
                />
                <img
                  src="/playground_assets/ellipse1263-aicm-200h.png"
                  alt="Ellipse1263"
                  className="home-ellipse12"
                />
                <span className="home-text48">
                  <span>Lorem ipsum</span>
                </span>
                <span className="home-text50">
                  <span>lorem ipsum</span>
                </span>
                <span className="home-text52">
                  <span>PEACHES</span>
                </span>
                <span className="home-text54">
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div className="home-frame3">
              <div className="home-group13">
                <div className="home-frame44">
                  <img
                    src="/playground_assets/tomatoes11215-dlvn-200h.png"
                    alt="tomatoes11215"
                    className="home-tomatoes113"
                  />
                </div>
                <img
                  src="/playground_assets/rectangle128-bks9-200h.png"
                  alt="Rectangle128"
                  className="home-rectangle13"
                />
                <img
                  src="/playground_assets/ellipse129-9ptr-200h.png"
                  alt="Ellipse129"
                  className="home-ellipse13"
                />
                <span className="home-text59">
                  <span>Lorem ipsum</span>
                </span>
                <span className="home-text61">
                  <span>lorem ipsum</span>
                </span>
                <span className="home-text63">
                  <span>TOMATOS</span>
                </span>
                <img
                  src="/playground_assets/line1212-b6qa.svg"
                  alt="Line1212"
                  className="home-line13"
                />
                <span className="home-text65">
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
