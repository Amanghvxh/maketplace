import React from 'react'

import { Helmet } from 'react-helmet'

import styles from './index.module.css'

const Home = (props) => {
  return (
    <div className={styles['container']}>
      <Helmet>
        <title>Made Up Spotless Emu</title>
        <meta property="og:title" content="Made Up Spotless Emu" />
      </Helmet>
      <div className={styles['frame1']}>
        <div className={styles['frame2']}>
          <img
            src="/playground_assets/a5343180082741d290fd3d2ea80d70e0125-7wa-1100w.png"
            alt="a5343180082741d290fd3d2ea80d70e0125"
            className={styles['a5343180082741d290fd3d2ea80d70e01']}
          />
        </div>
        <div className={styles['frame8']}>
          <span className={styles['text']}>
            <span>LOREM IPSUM LOREMUPSUM</span>
          </span>
          <span className={styles['text02']}>
            <span>
              <span>LOREM IPSUM</span>
              <br></br>
              <span>LOREMUPSUM</span>
            </span>
          </span>
          <span className={styles['text07']}>
            <span>
              LOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM
              LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPS
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </span>
          <img
            src="/playground_assets/rectangle2283-jwq-200h.png"
            alt="Rectangle2283"
            className={styles['rectangle2']}
          />
          <img
            src="/playground_assets/rectangle3285-vj.svg"
            alt="Rectangle3285"
            className={styles['rectangle3']}
          />
          <img
            src="/playground_assets/rectangle4286-kk1l-200h.png"
            alt="Rectangle4286"
            className={styles['rectangle4']}
          />
          <span className={styles['text09']}>
            <span>JOIN AS SELLER</span>
          </span>
          <span className={styles['text11']}>
            <span>JOIN AS BUYER</span>
          </span>
        </div>
        <div className={styles['frame7']}>
          <span className={styles['text13']}>
            <span>
              <span>LOGO</span>
              <br></br>
              <span>LOGO</span>
            </span>
          </span>
          <span className={styles['text18']}>
            <span>HOME</span>
          </span>
          <span className={styles['text20']}>
            <span>CONTACTUS</span>
          </span>
          <span className={styles['text22']}>
            <span>LOGIN</span>
          </span>
          <span className={styles['text24']}>
            <span>SIGNUP</span>
          </span>
        </div>
        <div className={styles['frame9']}>
          <div className={styles['frame10']}>
            <div className={styles['frame6']}>
              <div className={styles['group1']}>
                <div className={styles['frame4']}>
                  <img
                    src="/playground_assets/tomatoes11239-896-200h.png"
                    alt="tomatoes11239"
                    className={styles['tomatoes11']}
                  />
                </div>
                <img
                  src="/playground_assets/line1244-ojde.svg"
                  alt="Line1244"
                  className={styles['line1']}
                />
                <img
                  src="/playground_assets/rectangle1267-un7-200h.png"
                  alt="Rectangle1267"
                  className={styles['rectangle1']}
                />
                <img
                  src="/playground_assets/ellipse1268-52h-200h.png"
                  alt="Ellipse1268"
                  className={styles['ellipse1']}
                />
                <span className={styles['text26']}>
                  <span>Lorem ipsum</span>
                </span>
                <span className={styles['text28']}>
                  <span>lorem ipsum</span>
                </span>
                <span className={styles['text30']}>
                  <span>BLUEBERRIES</span>
                </span>
                <span className={styles['text32']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div className={styles['frame5']}>
              <div className={styles['group11']}>
                <div className={styles['frame41']}>
                  <img
                    src="/playground_assets/tomatoes11229-h4nf-200h.png"
                    alt="tomatoes11229"
                    className={styles['tomatoes111']}
                  />
                </div>
                <img
                  src="/playground_assets/line1234-bcec.svg"
                  alt="Line1234"
                  className={styles['line11']}
                />
                <img
                  src="/playground_assets/rectangle1257-w85m-200h.png"
                  alt="Rectangle1257"
                  className={styles['rectangle11']}
                />
                <img
                  src="/playground_assets/ellipse1258-cyed-200h.png"
                  alt="Ellipse1258"
                  className={styles['ellipse11']}
                />
                <span className={styles['text37']}>
                  <span>Lorem ipsum</span>
                </span>
                <span className={styles['text39']}>
                  <span>lorem ipsum</span>
                </span>
                <span className={styles['text41']}>
                  <span>GRAPES</span>
                </span>
                <span className={styles['text43']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div className={styles['frame42']}>
              <div className={styles['group12']}>
                <div className={styles['frame43']}>
                  <img
                    src="/playground_assets/tomatoes11219-spvk-200h.png"
                    alt="tomatoes11219"
                    className={styles['tomatoes112']}
                  />
                </div>
                <img
                  src="/playground_assets/line1224-gjkn.svg"
                  alt="Line1224"
                  className={styles['line12']}
                />
                <img
                  src="/playground_assets/rectangle1262-j15p-200h.png"
                  alt="Rectangle1262"
                  className={styles['rectangle12']}
                />
                <img
                  src="/playground_assets/ellipse1263-aicm-200h.png"
                  alt="Ellipse1263"
                  className={styles['ellipse12']}
                />
                <span className={styles['text48']}>
                  <span>Lorem ipsum</span>
                </span>
                <span className={styles['text50']}>
                  <span>lorem ipsum</span>
                </span>
                <span className={styles['text52']}>
                  <span>PEACHES</span>
                </span>
                <span className={styles['text54']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
            <div className={styles['frame3']}>
              <div className={styles['group13']}>
                <div className={styles['frame44']}>
                  <img
                    src="/playground_assets/tomatoes11215-dlvn-200h.png"
                    alt="tomatoes11215"
                    className={styles['tomatoes113']}
                  />
                </div>
                <img
                  src="/playground_assets/rectangle128-bks9-200h.png"
                  alt="Rectangle128"
                  className={styles['rectangle13']}
                />
                <img
                  src="/playground_assets/ellipse129-9ptr-200h.png"
                  alt="Ellipse129"
                  className={styles['ellipse13']}
                />
                <span className={styles['text59']}>
                  <span>Lorem ipsum</span>
                </span>
                <span className={styles['text61']}>
                  <span>lorem ipsum</span>
                </span>
                <span className={styles['text63']}>
                  <span>TOMATOS</span>
                </span>
                <img
                  src="/playground_assets/line1212-b6qa.svg"
                  alt="Line1212"
                  className={styles['line13']}
                />
                <span className={styles['text65']}>
                  <span>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                    <br></br>
                    <span>
                      Lorem ipsum Lorem ipsum
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
