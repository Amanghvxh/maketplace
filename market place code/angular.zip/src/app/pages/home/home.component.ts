import { Component } from '@angular/core'
import { Title, Meta } from '@angular/platform-browser'

@Component({
  selector: 'app-home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
})
export class Home {
  rawfqlg: string = ' '
  raw234g: string = ' '
  raw0a77: string = ' '
  rawdw4d: string = ' '
  rawwt9q: string = ' '
  rawrwug: string = ' '
  raw45kb: string = ' '
  raw6ozj: string = ' '
  rawiqwd: string = ' '

  constructor(private title: Title, private meta: Meta) {
    this.title.setTitle('Made Up Spotless Emu')
    this.meta.addTags([
      {
        property: 'og:title',
        content: 'Made Up Spotless Emu',
      },
    ])
  }
}
