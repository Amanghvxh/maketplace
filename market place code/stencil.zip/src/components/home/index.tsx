import { Component, h } from '@stencil/core'

@Component({
  tag: 'app-home',
  shadow: true,
  styleUrls: ['style.css'],
})
export class Home {
  render() {
    return (
      <div class="container">
        <stencil-route-title pageTitle="Made Up Spotless Emu" />
        <div class="frame1">
          <div class="frame2">
            <img
              src="/assets/playground_assets/a5343180082741d290fd3d2ea80d70e0125-7wa-1100w.png"
              alt="a5343180082741d290fd3d2ea80d70e0125"
              class="a5343180082741d290fd3d2ea80d70e01"
            />
          </div>
          <div class="frame8">
            <span class="text">
              <span>LOREM IPSUM LOREMUPSUM</span>
            </span>
            <span class="text02">
              <span>
                <span>LOREM IPSUM</span>
                <br></br>
                <span>LOREMUPSUM</span>
              </span>
            </span>
            <span class="text07">
              <span>
                LOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM
                LOREMUPSUMLOREM IPSUM LOREMUPSUMLOREM IPSUM LOREMUPS
                <span innerHTML=" " />
              </span>
            </span>
            <img
              src="/assets/playground_assets/rectangle2283-jwq-200h.png"
              alt="Rectangle2283"
              class="rectangle2"
            />
            <img
              src="/assets/playground_assets/rectangle3285-vj.svg"
              alt="Rectangle3285"
              class="rectangle3"
            />
            <img
              src="/assets/playground_assets/rectangle4286-kk1l-200h.png"
              alt="Rectangle4286"
              class="rectangle4"
            />
            <span class="text09">
              <span>JOIN AS SELLER</span>
            </span>
            <span class="text11">
              <span>JOIN AS BUYER</span>
            </span>
          </div>
          <div class="frame7">
            <span class="text13">
              <span>
                <span>LOGO</span>
                <br></br>
                <span>LOGO</span>
              </span>
            </span>
            <span class="text18">
              <span>HOME</span>
            </span>
            <span class="text20">
              <span>CONTACTUS</span>
            </span>
            <span class="text22">
              <span>LOGIN</span>
            </span>
            <span class="text24">
              <span>SIGNUP</span>
            </span>
          </div>
          <div class="frame9">
            <div class="frame10">
              <div class="frame6">
                <div class="group1">
                  <div class="frame4">
                    <img
                      src="/assets/playground_assets/tomatoes11239-896-200h.png"
                      alt="tomatoes11239"
                      class="tomatoes11"
                    />
                  </div>
                  <img
                    src="/assets/playground_assets/line1244-ojde.svg"
                    alt="Line1244"
                    class="line1"
                  />
                  <img
                    src="/assets/playground_assets/rectangle1267-un7-200h.png"
                    alt="Rectangle1267"
                    class="rectangle1"
                  />
                  <img
                    src="/assets/playground_assets/ellipse1268-52h-200h.png"
                    alt="Ellipse1268"
                    class="ellipse1"
                  />
                  <span class="text26">
                    <span>Lorem ipsum</span>
                  </span>
                  <span class="text28">
                    <span>lorem ipsum</span>
                  </span>
                  <span class="text30">
                    <span>BLUEBERRIES</span>
                  </span>
                  <span class="text32">
                    <span>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                      <br></br>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                    </span>
                  </span>
                </div>
              </div>
              <div class="frame5">
                <div class="group11">
                  <div class="frame41">
                    <img
                      src="/assets/playground_assets/tomatoes11229-h4nf-200h.png"
                      alt="tomatoes11229"
                      class="tomatoes111"
                    />
                  </div>
                  <img
                    src="/assets/playground_assets/line1234-bcec.svg"
                    alt="Line1234"
                    class="line11"
                  />
                  <img
                    src="/assets/playground_assets/rectangle1257-w85m-200h.png"
                    alt="Rectangle1257"
                    class="rectangle11"
                  />
                  <img
                    src="/assets/playground_assets/ellipse1258-cyed-200h.png"
                    alt="Ellipse1258"
                    class="ellipse11"
                  />
                  <span class="text37">
                    <span>Lorem ipsum</span>
                  </span>
                  <span class="text39">
                    <span>lorem ipsum</span>
                  </span>
                  <span class="text41">
                    <span>GRAPES</span>
                  </span>
                  <span class="text43">
                    <span>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                      <br></br>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                    </span>
                  </span>
                </div>
              </div>
              <div class="frame42">
                <div class="group12">
                  <div class="frame43">
                    <img
                      src="/assets/playground_assets/tomatoes11219-spvk-200h.png"
                      alt="tomatoes11219"
                      class="tomatoes112"
                    />
                  </div>
                  <img
                    src="/assets/playground_assets/line1224-gjkn.svg"
                    alt="Line1224"
                    class="line12"
                  />
                  <img
                    src="/assets/playground_assets/rectangle1262-j15p-200h.png"
                    alt="Rectangle1262"
                    class="rectangle12"
                  />
                  <img
                    src="/assets/playground_assets/ellipse1263-aicm-200h.png"
                    alt="Ellipse1263"
                    class="ellipse12"
                  />
                  <span class="text48">
                    <span>Lorem ipsum</span>
                  </span>
                  <span class="text50">
                    <span>lorem ipsum</span>
                  </span>
                  <span class="text52">
                    <span>PEACHES</span>
                  </span>
                  <span class="text54">
                    <span>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                      <br></br>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                    </span>
                  </span>
                </div>
              </div>
              <div class="frame3">
                <div class="group13">
                  <div class="frame44">
                    <img
                      src="/assets/playground_assets/tomatoes11215-dlvn-200h.png"
                      alt="tomatoes11215"
                      class="tomatoes113"
                    />
                  </div>
                  <img
                    src="/assets/playground_assets/rectangle128-bks9-200h.png"
                    alt="Rectangle128"
                    class="rectangle13"
                  />
                  <img
                    src="/assets/playground_assets/ellipse129-9ptr-200h.png"
                    alt="Ellipse129"
                    class="ellipse13"
                  />
                  <span class="text59">
                    <span>Lorem ipsum</span>
                  </span>
                  <span class="text61">
                    <span>lorem ipsum</span>
                  </span>
                  <span class="text63">
                    <span>TOMATOS</span>
                  </span>
                  <img
                    src="/assets/playground_assets/line1212-b6qa.svg"
                    alt="Line1212"
                    class="line13"
                  />
                  <span class="text65">
                    <span>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                      <br></br>
                      <span>
                        Lorem ipsum Lorem ipsum
                        <span innerHTML=" " />
                      </span>
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
